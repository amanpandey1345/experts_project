// navbar show hide logic


function mobileMenuShow() {
    let show = document.getElementById('myDIV').style.display = "block";
    let hide = document.getElementById('logoClass').style.display = "none";
}

function mobileMenuHide() {
    let hide = document.getElementById('myDIV').style.display = "none"
    let show = document.getElementById('logoClass').style.display = "block";

}


